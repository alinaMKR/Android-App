package Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.nutritionlog.R;

import java.util.List;

import Model.Meal;

public class ItemConsumedAdapter extends RecyclerView.Adapter<ItemConsumedAdapter.ItemViewHolder> {
    private List<Meal> meal;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
        void onDeleteClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        public TextView textName;
        public TextView textCategory;
        public TextView textCalories;
        public TextView textFat;
        public TextView textProtein;
        public TextView textCarbs;
        public ImageView mDeleteImage;

        public ItemViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);
            textName = itemView.findViewById(R.id.consumed_name);
            textCategory = itemView.findViewById(R.id.consumed_category);
            textCalories = itemView.findViewById(R.id.consumed_calories);
            textFat = itemView.findViewById(R.id.consumed_fat);
            textProtein = itemView.findViewById(R.id.consumed_protein);
            textCarbs = itemView.findViewById(R.id.consumed_carbs);
            mDeleteImage = itemView.findViewById(R.id.image_delete);

            /*
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });

             */
            mDeleteImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onDeleteClick(position);

                        }
                    }
                }
            });
        }
    }
    public ItemConsumedAdapter(List<Meal> meal) {
        this.meal = meal;
    }
    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.consumed_layout, parent, false);
        ItemViewHolder viewHolder = new ItemViewHolder(v, mListener);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        int mealId = meal.get(position).getId();
        holder.itemView.setTag(mealId);
        holder.textName.setText(meal.get(position).getName());
        holder.textCategory.setText(meal.get(position).getCategory());
        Double doubleCalories = meal.get(position).getCalories();
        String stringCalories = Double.toString(doubleCalories);
        holder.textCalories.setText(stringCalories);
        Double doubleFat = meal.get(position).getFat();
        String stringFat = Double.toString(doubleFat);
        holder.textFat.setText(stringFat);
        Double doubleProtein = meal.get(position).getProtein();
        String stringProtein = Double.toString(doubleProtein);
        holder.textProtein.setText(stringProtein);
        Double doubleCarbs = meal.get(position).getCarbs();
        String stringCarbs = Double.toString(doubleCarbs);
        holder.textCarbs.setText(stringCarbs);
        String mealType = meal.get(position).getMealType();
        String date = meal.get(position).getDate();

    }
    @Override
    public int getItemCount() {
        return meal.size();
    }
}
