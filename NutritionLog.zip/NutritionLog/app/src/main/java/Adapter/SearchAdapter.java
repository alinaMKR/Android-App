package Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.nutritionlog.AddSelectedFood;
import com.example.nutritionlog.ItemClickListener;
import com.example.nutritionlog.R;

import java.util.List;

import Model.Food;


class SearchViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{
    public TextView name, category;


    private ItemClickListener itemClickListener;


    public SearchViewHolder(View itemView) {
        super(itemView);
        name = (TextView) itemView.findViewById(R.id.name);
        category = (TextView) itemView.findViewById(R.id.category);

        itemView.setOnClickListener(this);
        itemView.setOnLongClickListener(this);

    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @Override
    public void onClick(View v) {
        itemClickListener.onClick(v, getAdapterPosition(),false);

    }

    @Override
    public boolean onLongClick(View v) {
        itemClickListener.onClick(v, getAdapterPosition(), true);
        return true;
    }
}
public class SearchAdapter extends RecyclerView.Adapter<SearchViewHolder> {
    public static final String EXTRA_TEXT = "com.example.NutritionLog.example.EXTRA_TEXT";
    public static final String EXTRA_TEXT1 = "com.example.NutritionLog.example.EXTRA_TEXT1";
    public static final String EXTRA_TEXT2 = "com.example.NutritionLog.example.EXTRA_TEXT2";
    public static final String EXTRA_TEXT3 = "com.example.NutritionLog.example.EXTRA_TEXT3";
    public static final String EXTRA_TEXT4 = "com.example.NutritionLog.example.EXTRA_TEXT4";
    public static final String EXTRA_TEXT5 = "com.example.NutritionLog.example.EXTRA_TEXT5";
    private Context context;
    private List<Food> food;


    public SearchAdapter(Context context, List<Food> food){
        this.context = context;
        this.food = food;
    }


    @Override
    public SearchViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.layout_item, parent,false);
        return new SearchViewHolder(itemView);


    }

    @Override
    public void onBindViewHolder(SearchViewHolder holder, int position) {
        holder.name.setText(food.get(position).getName());
        holder.category.setText(food.get(position).getCategory());

        holder.setItemClickListener(new ItemClickListener(){
            @Override
            public void onClick(View view, int position, boolean isLongClick){
                if (isLongClick){
                    Toast.makeText(context, "View Details: \nCalories: "+ food.get(position).getCalories()
                            + "\nFat: "+ food.get(position).getFat()
                            + "\nProtein: "+ food.get(position).getProtein()
                            + "\nCarbs: "+ food.get(position).getCarbs(), Toast.LENGTH_SHORT).show();
                }
                else{
                    String itemName = food.get(position).getName();
                    String itemCategory = food.get(position).getCategory();
                    Double foodCalories = food.get(position).getCalories();
                    String itemCalories = Double.toString(foodCalories);
                    Double foodFat = food.get(position).getFat();
                    String itemFat = Double.toString(foodFat);
                    Double foodProtein = food.get(position).getProtein();
                    String itemProtein = Double.toString(foodProtein);
                    Double foodCarbs = food.get(position).getCarbs();
                    String itemCarbs = Double.toString(foodCarbs);
                    openFoodSelected(itemName, itemCategory, itemCalories, itemFat
                    , itemProtein, itemCarbs);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return food.size();
    }

    public void openFoodSelected(String name, String category, String calories
                , String fat, String protein, String carbs){
        Intent intent = new Intent(context, AddSelectedFood.class);
        intent.putExtra(EXTRA_TEXT, name);
        intent.putExtra(EXTRA_TEXT1, category);
        intent.putExtra(EXTRA_TEXT2, calories);
        intent.putExtra(EXTRA_TEXT3, fat);
        intent.putExtra(EXTRA_TEXT4, protein);
        intent.putExtra(EXTRA_TEXT5, carbs);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

}
