package Model;

public class Meal {
    public int id;
    public String name, category, mealType, date;
    public double calories, fat, protein, carbs;

    public Meal(int id, String name, String category, double calories, double fat, double protein, double carbs
                , String mealType, String date){
        this.calories = calories;
        this.fat = fat;
        this.name = name;
        this.protein = protein;
        this.category = category;
        this.carbs = carbs;
        this.id = id;
        this.mealType = mealType;
        this.date = date;
    }

    public Meal(){
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getFat() {
        return fat;
    }

    public void setFat(double fat) {
        this.fat = fat;
    }

    public double getProtein() {
        return protein;
    }

    public void setProtein(double protein) {
        this.protein = protein;
    }

    public double getCarbs() {
        return carbs;
    }

    public void setCarbs(double carbs) {
        this.carbs = carbs;
    }

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}

