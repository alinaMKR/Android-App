package com.example.nutritionlog;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import databases.Database;
import databases.DatabaseConsumedFood;

public class AddNewFood extends AppCompatActivity {
    //declare variables to retrieve text from them
    Database database;
    EditText name;
    EditText category;
    EditText calories;
    EditText fat;
    EditText protein;
    EditText carbs;
    int id = 300;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_food);

        getSupportActionBar().setTitle("Add New Food type");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        database = new Database(this);

        name = (EditText)findViewById(R.id.edit_new_name);
        category = (EditText)findViewById(R.id.edit_new_category);
        calories = (EditText)findViewById(R.id.edit_new_calories);
        fat = (EditText)findViewById(R.id.edit_new_fat);
        protein = (EditText)findViewById(R.id.edit_new_protein);
        carbs = (EditText)findViewById(R.id.edit_new_carbs);

    }
     public void btnAddNewFood(View view){
        id++;
        //get string values and convert to double
        String foodCalories = calories.getText().toString();
        double dCalories = Double.parseDouble(foodCalories);
         String foodFat = fat.getText().toString();
         double dFat = Double.parseDouble(foodFat);
         String foodProtein = protein.getText().toString();
         double dProtein = Double.parseDouble(foodProtein);
         String foodCarbs = carbs.getText().toString();
         double dCarbs = Double.parseDouble(foodCarbs);

         //insert new values to database
        database.insertFoodItem(id, name.getText().toString(),category.getText().toString()
                ,dCalories, dFat, dProtein, dCarbs);
         Toast.makeText(this, "Item has been added", Toast.LENGTH_SHORT).show();

     }
}