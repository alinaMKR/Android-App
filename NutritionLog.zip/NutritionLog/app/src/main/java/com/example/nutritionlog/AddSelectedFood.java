package com.example.nutritionlog;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import Adapter.SearchAdapter;
import databases.Database;
import databases.DatabaseConsumedFood;


public class AddSelectedFood extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    //declare database with consumed food
    DatabaseConsumedFood dbConsumed;
    TextView foodName, foodCategory, foodCalories, foodFat, foodProtein, foodCarbs;
    Spinner mealSpinner;
    String spinnerText;

    //declare vaiables for date picker
    TextView date;
    Calendar calendar;
    DatePickerDialog datePickerDialog;
    int year;
    int month;
    int dayOfMonth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_selected_food);
        getSupportActionBar().setTitle("Add Selected Food");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        DateFormat formatter;

        //initialize database with consumed food
        dbConsumed = new DatabaseConsumedFood(this,"", null, 1);
        //get intent
        Intent intent = getIntent();
        //pass values that were clicked in SearchAdapter
        final String name = intent.getStringExtra(SearchAdapter.EXTRA_TEXT);
        final String category = intent.getStringExtra(SearchAdapter.EXTRA_TEXT1);
        String calories = intent.getStringExtra(SearchAdapter.EXTRA_TEXT2);
        String fat = intent.getStringExtra(SearchAdapter.EXTRA_TEXT3);
        String protein = intent.getStringExtra(SearchAdapter.EXTRA_TEXT4);
        String carbs = intent.getStringExtra(SearchAdapter.EXTRA_TEXT5);


        //create spinner to select meal
        mealSpinner = findViewById(R.id.mealSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.meal, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mealSpinner.setAdapter(adapter);
        mealSpinner.setOnItemSelectedListener(this);

        //get text views and set values as from clicked food item
        foodName = (TextView)findViewById(R.id.item_food_name);
        foodName.setText(name);
        foodCategory = (TextView)findViewById(R.id.item_category_name);
        foodCategory.setText(category);
        foodCalories = (TextView)findViewById(R.id.item_calories);
        foodCalories.setText(calories);
        foodFat = (TextView)findViewById(R.id.item_fat);
        foodFat.setText(fat);
        foodProtein = (TextView)findViewById(R.id.item_protein);
        foodProtein.setText(protein);
        foodCarbs = (TextView)findViewById(R.id.item_carbs);
        foodCarbs.setText(carbs);




        /* Change this
        value1 = Spinner1.getSelectedItem().toString();
        spinnerMeal = String.valueOf(parent.getItemAtPosition(pos));
         */
        //create variable for calendar
        date = findViewById(R.id.date_consumed);
        //create a date string.
        String date_n = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        //set it as current date.
        date.setText(date_n);
        //set the click listener to choose the date
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get current date
                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(AddSelectedFood.this,
                        new DatePickerDialog.OnDateSetListener() {
                            //get date from dialog and set in a proper format
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                date.setText(day+"/"+(month+1) +"/"+year);
                            }
                        }, year, month, dayOfMonth);
                datePickerDialog.show();
            }
        });


    }

    //display the selected meal type from spinner list
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        spinnerText = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        spinnerText = "Breakfast";

    }

    public void btnAddFood(View view) throws ParseException {
        //parse string to double before passing it to insertFood method
        String calories = foodCalories.getText().toString();
        double dCalories = Double.parseDouble(calories);
        String fat = foodFat.getText().toString();
        double dFat = Double.parseDouble(fat);
        String protein = foodProtein.getText().toString();
        double dProtein = Double.parseDouble(protein);
        String carbs = foodCarbs.getText().toString();
        double dCarbs = Double.parseDouble(carbs);
        CharSequence charDate = date.getText();
        String strDate = charDate.toString();
        Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(strDate);
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = formatter.format(date1);
        dbConsumed.insertMeal(foodName.getText().toString(), foodCategory.getText().toString()
                , dCalories, dFat, dProtein, dCarbs, spinnerText, dateString);
        Toast.makeText(this, "Item has been added", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(AddSelectedFood.this, MainActivity.class);
        startActivity(intent);
    }
}