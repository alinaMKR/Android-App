package com.example.nutritionlog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import Adapter.ItemConsumedAdapter;
import Model.Meal;
import databases.DatabaseConsumedFood;

public class DisplayBreakfast extends AppCompatActivity {
    //declare vaiables for date picker
    TextView date;
    String date_n;
    Calendar calendar;
    DatePickerDialog datePickerDialog;
    int year;
    int month;
    int dayOfMonth;
    List<Meal> meal;

    public TextView name, category, calories, fat, protein, carbs;

    private RecyclerView mRecyclerView;
    private ItemConsumedAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    DatabaseConsumedFood dbConsumed;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_breakfast);
        getSupportActionBar().setTitle("Display Breakfast");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //create variable for calendar
        date = findViewById(R.id.breakfast_date);
        //create a date string.
        date_n = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        //set it as current date.
        date.setText(date_n);

        try {
            createItemList();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        buildRecyclerView();

        //set the click listener to choose the date
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get current date
                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(DisplayBreakfast.this,
                        new DatePickerDialog.OnDateSetListener() {
                            //get date from dialog and set in a proper format
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                date_n =day+"/"+(month+1) +"/"+year;
                                date.setText(date_n);
                                try {
                                    createItemList();
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                                buildRecyclerView();
                            }
                        }, year, month, dayOfMonth);
                datePickerDialog.show();
            }
        });



    }

    public void removeItem(int position) {
        int intId = meal.get(position).getId();
        String strId = Integer.toString(intId);
        dbConsumed.deleteMeal(strId);
        meal.remove(position);
        mAdapter.notifyItemRemoved(position);

    }
    public void removeById(int id){
        String stringId = Integer.toString(id);
        dbConsumed.deleteMeal(stringId);
    }

    public void createItemList() throws ParseException {
        meal = new ArrayList<>();
        dbConsumed = new DatabaseConsumedFood(this,"", null, 1);
        Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(date_n);
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = formatter.format(date1);
        meal = dbConsumed.getBreakfastByDate(dateString);

    }

    public void buildRecyclerView() {
        mRecyclerView = findViewById(R.id.recyclerView);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ItemConsumedAdapter(meal);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setHasFixedSize(true);

        mAdapter.setOnItemClickListener(new ItemConsumedAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }

            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
            }
        });
    }

}