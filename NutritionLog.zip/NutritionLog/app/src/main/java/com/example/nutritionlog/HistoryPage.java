package com.example.nutritionlog;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import databases.DatabaseConsumedFood;

public class HistoryPage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner timeSpinner;
    String spinnerText;
    Instant now;
    TextView totalCal, totalFat, totalProtein, totalCarbs;
    DatabaseConsumedFood dbConsumed;
    String weekDate;
    String monthDate;
    String threeMonthsDate;
    String curDate;

    private static final String LOG_TAG = HistoryPage.class.getSimpleName();

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_page);
        getSupportActionBar().setTitle("History");

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        //Set home selected
        bottomNavigationView.setSelectedItemId(R.id.history);

        //Create listener for item
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.history:
                        return true;
                    case R.id.profile:
                        startActivity(new Intent(getApplicationContext()
                                , ProfileStartActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext()
                                , MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });


        //Get last week
        now = Instant.now(); //current date
        Instant weekBefore = now.minus(Duration.ofDays(7));
        Date dateWeekBefore = Date.from(weekBefore);
        curDate= new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        weekDate = formatter.format(dateWeekBefore);

        //Get last month
        Instant monthBefore = now.minus(Duration.ofDays(31));
        Date dateMonthBefore = Date.from(monthBefore);
        monthDate = formatter.format(dateMonthBefore);

        //Get last 3 months
        Instant threeMonthsBefore = now.minus(Duration.ofDays(92));
        Date dateThreeMonthsBefore = Date.from(threeMonthsBefore);
        threeMonthsDate = formatter.format(dateThreeMonthsBefore);

        //Find text views to display results
        totalCal = findViewById(R.id.history_calories);
        totalFat = findViewById(R.id.history_fat);
        totalProtein = findViewById(R.id.history_protein);
        totalCarbs = findViewById(R.id.history_carbs);



        //create spinner to select time range
        Spinner timeSpinner = findViewById(R.id.time_range_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.timeRange, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        timeSpinner.setAdapter(adapter);
        timeSpinner.setOnItemSelectedListener(this);
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        spinnerText = parent.getItemAtPosition(position).toString();
        if (spinnerText.equalsIgnoreCase("Last week")) {
            try {
                displayHistoryByTimeRage(weekDate);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (spinnerText.equalsIgnoreCase("Last month")) {
            try {
                displayHistoryByTimeRage(monthDate);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (spinnerText.equalsIgnoreCase("Last 3 months")) {
            try {
                displayHistoryByTimeRage(threeMonthsDate);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }




    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {


    }

    public void displayHistoryByTimeRage(String dateRange) throws IOException {
        //CALORIES
        //extract values for current date
        List<String> caloriesByWeek = new ArrayList<>();
        dbConsumed = new DatabaseConsumedFood(this,"", null, 1);
        caloriesByWeek = dbConsumed.getCaloriesByTimeRange(dateRange);
        double totCalByWeek = 0;
        double[] calDouble = new double[caloriesByWeek.size()];
        for (int i = 0; i < caloriesByWeek.size(); ++i) {
            calDouble[i] = Double.parseDouble(caloriesByWeek.get(i));
            totCalByWeek += calDouble[i];
        }
        String calPerWeek = String.format("%.2f", totCalByWeek);
        totalCal.setText(calPerWeek);

        //FAT
        //extract values for current date
        List<String> fatByWeek = new ArrayList<>();
        fatByWeek = dbConsumed.getFatByTimeRange(dateRange);
        double totFatByWeek = 0;
        double[] fatDouble = new double[fatByWeek.size()];
        for (int i = 0; i < fatByWeek.size(); ++i) {
            fatDouble[i] = Double.parseDouble(fatByWeek.get(i));
            totFatByWeek += fatDouble[i];
        }
        String fatPerWeek = String.format("%.2f", totFatByWeek);
        totalFat.setText(fatPerWeek + " g");

        //PROTEIN
        //extract values for current date
        List<String> proteinByWeek = new ArrayList<>();
        proteinByWeek = dbConsumed.getProteinByTimeRange(dateRange);
        double totProteinByWeek = 0;
        double[] proteinDouble = new double[proteinByWeek.size()];
        for (int i = 0; i < proteinByWeek.size(); ++i) {
            proteinDouble[i] = Double.parseDouble(proteinByWeek.get(i));
            totProteinByWeek += proteinDouble[i];
        }
        String proteinPerWeek = String.format("%.2f", totProteinByWeek);
        totalProtein.setText(proteinPerWeek + " g");

        //CARBS
        //extract values for current date
        List<String> carbsByWeek = new ArrayList<>();
        carbsByWeek = dbConsumed.getCarbsByTimeRange(dateRange);
        double totCarbsByDate = 0;
        double[] carbsDouble = new double[carbsByWeek.size()];
        for (int i = 0; i < carbsByWeek.size(); ++i) {
            carbsDouble[i] = Double.parseDouble(carbsByWeek.get(i));
            totCarbsByDate += carbsDouble[i];
        }
        String carbsPerWeek = String.format("%.2f", totCarbsByDate);
        totalCarbs.setText(carbsPerWeek + " g");
    }


}
