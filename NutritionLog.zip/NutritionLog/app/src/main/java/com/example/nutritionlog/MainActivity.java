package com.example.nutritionlog;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import Model.Meal;
import databases.DatabaseConsumedFood;

public class MainActivity extends AppCompatActivity {
    //declare variables needed for FAB animation
    FloatingActionButton fab_add, fab_consumed, fab_new_food;
    Animation fabOpen, fabClose, rotateFrom, rotateTo;

    //declare necessary variables
    TextView textConsumed;
    TextView textNewType;
    boolean isOpen = false;
    private static final String FILE_NAME = "internal.txt";
    StringBuilder sb = new StringBuilder();
    List<String> stringArray = new ArrayList<>();
    TextView name, calGoal;
    Double BMS, goalDouble;
    String ageString, heightString, weightString, goalString, genderString;
    String neededCal;
    Double goalCal, totCalByDate;
    PieChart pieChart;
    Float consumedValue, leftValue;
    PieData pieData;

    //declare vaiables for date picker
    TextView date;
    Calendar calendar;
    DatePickerDialog datePickerDialog;
    int year;
    int month;
    int dayOfMonth;
    CardView card1, card2;

    //declare variables oto display resuts
    TextView totalCal, totalFat, totalProtein, totalCarbs, dateMain;
    DatabaseConsumedFood dbConsumed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        //Set home selected
        bottomNavigationView.setSelectedItemId(R.id.home);

        //Create listener for item
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.history:
                        startActivity(new Intent(getApplicationContext()
                                , HistoryPage.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.profile:
                        startActivity(new Intent(getApplicationContext()
                                , ProfileStartActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.home:
                        return true;
                }
                return false;
            }
        });

        //create variable for calendar
        date = findViewById(R.id.date_main);
        //create a date string.
        String date_n = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        //set it as current date.
        date.setText(date_n);

        //Find text views to display results
        totalCal = findViewById(R.id.total_calories);
        totalFat = findViewById(R.id.total_fat);
        totalProtein = findViewById(R.id.total_protein);
        totalCarbs = findViewById(R.id.total_carbs);
        name = findViewById(R.id.welcome);
        calGoal = findViewById(R.id.left_calories);

        //CALCULATE CONSUMED NUTRIENTS
        calculateNutrients();
        readFile();
        displayGoalCalories();
        getPieChart();

        //initialize PieChart
        pieChart = findViewById(R.id.pieChart);

        //set the click listener to choose the date
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get current date
                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(MainActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            //get date from dialog and set in a proper format
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                                date.setText(day+"/"+(month+1) +"/"+year);
                                calculateNutrients();
                                readFile();
                                displayGoalCalories();
                                getPieChart();

                            }
                        }, year, month, dayOfMonth);

                datePickerDialog.show();

            }
        });


        //find FABs
        fab_add = findViewById(R.id.add_new_fab);
        fab_consumed = findViewById(R.id.add_consumed_food);
        fab_new_food = findViewById(R.id.add_new_food_type);
        card1 = findViewById(R.id.visib_card1);
        card2 = findViewById(R.id.visib_card2);

        //find text for FABs
        textConsumed = findViewById(R.id.txt_add_consumed);
        textNewType = findViewById(R.id.text_add_new_type);

        fabOpen = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.from_bottom_anim);
        fabClose = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.to_bottom_anim);
        rotateFrom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_open_anim);
        rotateTo = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_close_anim);

        fab_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isOpen){
                    fab_consumed.startAnimation(fabClose);
                    fab_new_food.startAnimation(fabClose);
                    fab_add.startAnimation(rotateTo);

                    fab_consumed.setClickable(false);
                    fab_new_food.setClickable(false);

                    textConsumed.setVisibility(View.INVISIBLE);
                    textNewType.setVisibility(View.INVISIBLE);
                    card1.setVisibility(View.INVISIBLE);
                    card2.setVisibility(View.INVISIBLE);

                    isOpen = false;
                }
                else{
                    fab_consumed.startAnimation(fabOpen);
                    fab_new_food.startAnimation(fabOpen);
                    fab_add.startAnimation(rotateFrom);

                    fab_consumed.setClickable(true);
                    fab_new_food.setClickable(true);

                    textConsumed.setVisibility(View.VISIBLE);
                    textNewType.setVisibility(View.VISIBLE);
                    card1.setVisibility(View.VISIBLE);
                    card2.setVisibility(View.VISIBLE);

                    isOpen = true;
                }
            }
        });

        fab_consumed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSelectFood();
            }
        });

        fab_new_food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddNewFood();
            }
        });

    }

    public void btnBreakfast(View view){
        Intent intent = new Intent(this, DisplayBreakfast.class);
        startActivity(intent);
    }

    public void btnLunch(View view){
        Intent intent = new Intent(this, DisplayLunch.class);
        startActivity(intent);
    }

    public void btnDinner(View view){
        Intent intent = new Intent(this, DisplayDinner.class);
        startActivity(intent);
    }

    public void openSelectFood(){
        Intent intent = new Intent(this, AddFood.class);
        startActivity(intent);
    }

    public void openAddNewFood(){
        Intent intent = new Intent(this, AddNewFood.class);
        startActivity(intent);
    }

    public void readFile(){
        //read info from file
        FileInputStream fis = null;
        File tempFile = new File("/data/data/com.example.nutritionlog/files/internal.txt");
        if (tempFile.exists()) {
            try {
                fis = openFileInput(FILE_NAME);
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader br = new BufferedReader(isr);
                String text;

                int line;
                while ((text=br.readLine())!=null){
                    sb.append(text).append("\n");
                    stringArray.add(text);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                try {
                    if(fis != null) {
                        fis.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(fis != null) {
                int i;
                for (i = 0; i <= stringArray.size(); ++i) {
                    name.setText("Hi, " + stringArray.get(0));
                    ageString = stringArray.get(1) + "years";
                    ageString = stringArray.get(1);
                    genderString = stringArray.get(2);
                    heightString = stringArray.get(3);
                    weightString = stringArray.get(4);
                    goalString = stringArray.get(5);
                }
            }
        }
    }

    public void displayGoalCalories(){
        double heightDouble = Double.parseDouble(heightString);
        double weightDouble = Double.parseDouble(weightString);
        goalDouble = Double.parseDouble(goalString);
        int ageInt = Integer.parseInt(ageString);

        /* Formula for bmr calculation
            FOR MEN:
            BMR = (10 x weight in kg) + (6.25 × height in cm) - (5 × age in years) + 5
            FOR WOMEN
            BMR = (10 x weight in kg) + (6.25 × height in cm) - (5 × age in years) - 161
             */
        if (genderString.equalsIgnoreCase("Female")){
            BMS = (10*weightDouble) + (6.25*heightDouble) - (5*ageInt) - 161;
        }
        if (genderString.equalsIgnoreCase("Male")){
            BMS = (10*weightDouble) + (6.25*heightDouble) - (5*ageInt) + 5;
        }
        if (goalString.equalsIgnoreCase(weightString)){
            goalCal = BMS;
        }
        if (goalDouble > weightDouble){
            goalCal = BMS + 300;
        }
        if (goalDouble < weightDouble){
            goalCal = BMS - 50;
        }
        int intGoal  = (int)(Math.round(goalCal));
        neededCal = Integer.toString(intGoal);

        int calInt = (int) (Math.round(totCalByDate));
        int leftCal  = intGoal - calInt;
        if (leftCal>0){
            calGoal.setText("Just " + leftCal + " kcal more!");
        }
        if (leftCal<=0){
            calGoal.setText("You reached your\ngoal");
        }
    }
    public void getPieChart() {
        consumedValue = 0f;
        leftValue = 100f;
        if (!stringArray.get(0).equalsIgnoreCase("")) {
            if (totCalByDate >= BMS) {
                consumedValue = 100f;
                leftValue = 0f;
            }
            if (totCalByDate < BMS) {
                double consumedV = (100 * totCalByDate) / BMS;
                consumedValue = (float) consumedV;
                leftValue = 100f - consumedValue;
            }
            List<PieEntry> values = new ArrayList<>();
            values.add(new PieEntry(consumedValue, "Consumed"));
            values.add(new PieEntry(leftValue, "Left"));

            PieDataSet pieDataSet = new PieDataSet(values, " ");
            pieData = new PieData(pieDataSet);
            pieDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
            pieDataSet.setValueTextSize(14);
            //initialize PieChart
            pieChart = findViewById(R.id.pieChart);
            pieChart.setData(pieData);
            pieChart.setUsePercentValues(true);

            Legend legend = pieChart.getLegend();
            legend.setEnabled(false);

            pieChart.setCenterText("CONSUMED\nCALORIES");
            pieChart.setCenterTextSize(14);
            pieChart.setEntryLabelTextSize(14);
            pieChart.setEntryLabelColor(Color.BLACK);
            pieChart.setNoDataText("");
            pieChart.setDrawEntryLabels(true);


            //add pie chart desc
            Description desc = new Description();
            desc.setText("");
            pieChart.setDescription(desc);
            //set Radius
            pieChart.setHoleRadius(50f);
            pieChart.setTransparentCircleRadius(50f);
            //animate pieChart
            pieChart.animateXY(1400, 1400);
        }
    }

    public void calculateNutrients(){
        //CALORIES
        //extract values for current date
        List<String> caloriesByDate = new ArrayList<>();
        dbConsumed = new DatabaseConsumedFood(this,"", null, 1);
        CharSequence charDate = date.getText();
        String dateS = charDate.toString();
        Date date1 = null;
        try {
            date1 = new SimpleDateFormat("dd/MM/yyyy").parse(dateS);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = formatter.format(date1);
        caloriesByDate = dbConsumed.getCaloriesBydate(dateString);
        totCalByDate = 0.0;
        double[] calDouble = new double[caloriesByDate.size()];
        for (int i = 0; i < caloriesByDate.size(); ++i) {
            calDouble[i] = Double.parseDouble(caloriesByDate.get(i));
            totCalByDate += calDouble[i];
        }
        int totCal = (int) (Math.round(totCalByDate));
        String calPerDay = Integer.toString(totCal);
        totalCal.setText(calPerDay);

        //FAT
        //extract values for current date
        List<String> fatByDate = new ArrayList<>();
        fatByDate = dbConsumed.getFatByDate(dateString);
        double totFatByDate = 0;
        double[] fatDouble = new double[fatByDate.size()];
        for (int i = 0; i < fatByDate.size(); ++i) {
            fatDouble[i] = Double.parseDouble(fatByDate.get(i));
            totFatByDate += fatDouble[i];
        }
        String fatPerDay = String.format("%.2f", totFatByDate);
        totalFat.setText(fatPerDay + "g");

        //PROTEIN
        //extract values for current date
        List<String> proteinByDate = new ArrayList<>();
        proteinByDate = dbConsumed.getProteinByDate(dateString);
        double totProteinByDate = 0;
        double[] proteinDouble = new double[proteinByDate.size()];
        for (int i = 0; i < proteinByDate.size(); ++i) {
            proteinDouble[i] = Double.parseDouble(proteinByDate.get(i));
            totProteinByDate += proteinDouble[i];
        }
        String proteinPerDay = String.format("%.2f", totProteinByDate);
        totalProtein.setText(proteinPerDay + "g");

        //CARBS
        //extract values for current date
        List<String> carbsByDate = new ArrayList<>();
        carbsByDate = dbConsumed.getCarbsByDate(dateString);
        double totCarbsByDate = 0;
        double[] carbsDouble = new double[carbsByDate.size()];
        for (int i = 0; i < carbsByDate.size(); ++i) {
            carbsDouble[i] = Double.parseDouble(carbsByDate.get(i));
            totCarbsByDate += carbsDouble[i];
        }
        String carbsPerDay = String.format("%.2f", totCarbsByDate);
        totalCarbs.setText(carbsPerDay + "g");

    }

}

