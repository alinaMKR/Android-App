package com.example.nutritionlog;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

public class ProfilePage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText name, height, weight, goal;
    String spinnerText;
    Button save;

    private static final String FILE_NAME = "internal.txt";

    //declare variable for DOB date picker
    TextView date;
    DatePickerDialog datePickerDialog;
    int year;
    int month;
    int dayOfMonth;
    Calendar calendar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        getSupportActionBar().setTitle("Edit Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        date = findViewById(R.id.dobCalendar);

        //create spinner to select gender
        Spinner genderSpinner = findViewById(R.id.genderSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.gender, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(adapter);
        genderSpinner.setOnItemSelectedListener(this);

        name = findViewById(R.id.editTextName);
        height = findViewById(R.id.editTextHeight);
        weight = findViewById(R.id.editTextWeight);
        goal = findViewById(R.id.goal_weight);
        save = findViewById(R.id.save_profile);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    saveChanges();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public void saveChanges() throws IOException {
        FileOutputStream fos = null;
        String dateS = date.getText().toString();
        String nameS = name.getText().toString();
        String heightS = height.getText().toString();
        String weightS = weight.getText().toString();
        String goalS = goal.getText().toString();

        try {
            fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
            fos.write(nameS.getBytes());
            fos.write("\n".getBytes());
            fos.write(dateS.getBytes());
            fos.write("\n".getBytes());
            fos.write(spinnerText.getBytes());
            fos.write("\n".getBytes());
            fos.write(heightS.getBytes());
            fos.write("\n".getBytes());
            fos.write(weightS.getBytes());
            fos.write("\n".getBytes());
            fos.write(goalS.getBytes());
            Toast.makeText(ProfilePage.this, "Changes have been saved", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            fos.close();
        }
        Intent intent = new Intent(this, ProfileStartActivity.class);
        //intent.putExtra(FILE_NAME, "internal.txt");
        startActivity(intent);

    }

    //display the selected gender from spinner list
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        spinnerText = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        spinnerText = "Male";

    }


}