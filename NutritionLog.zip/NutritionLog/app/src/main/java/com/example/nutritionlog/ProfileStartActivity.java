package com.example.nutritionlog;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ProfileStartActivity extends AppCompatActivity {
    private static final String FILE_NAME = "internal.txt";
    StringBuilder sb = new StringBuilder();
    List<String> stringArray = new ArrayList<>();
    TextView name, gender, dob, height, weight, goal, cal_goal;
    Double BMS;
    Double goalCal;
    String nameString;
    String heightString;
    String weightString;
    String ageString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_start);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        getSupportActionBar().setTitle("Profile");

        //Set home selected
        bottomNavigationView.setSelectedItemId(R.id.profile);

        //Create listener for item
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.history:
                        startActivity(new Intent(getApplicationContext()
                                , HistoryPage.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.profile:
                        return true;
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext()
                                , MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        name = findViewById(R.id.name);
        gender = findViewById(R.id.gender);
        dob = findViewById(R.id.dob);
        height = findViewById(R.id.height);
        weight = findViewById(R.id.weight);
        goal = findViewById(R.id.goal);
        cal_goal = findViewById(R.id.cal_goal);

        Button edit = findViewById(R.id.edit_profile);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditProfile();
            }
        });

        readFile();

    }

    public void displayGoalCalories(){
        String genderString = gender.getText().toString();
        String goalString = goal.getText().toString();

        double heightDouble = Double.parseDouble(heightString);
        double weightDouble = Double.parseDouble(weightString);
        double goalDouble = Double.parseDouble(goalString);
        int ageInt = Integer.parseInt(ageString);

        /* Formula for bmr calculation
            FOR MEN:
            BMR = (10 x weight in kg) + (6.25 × height in cm) - (5 × age in years) + 5
            FOR WOMEN
            BMR = (10 x weight in kg) + (6.25 × height in cm) - (5 × age in years) - 161
             */
        if (genderString.equalsIgnoreCase("Female")){
            BMS = (10*weightDouble) + (6.25*heightDouble) - (5*ageInt) - 161;
        }
        if (genderString.equalsIgnoreCase("Male")){
            BMS = (10*weightDouble) + (6.25*heightDouble) - (5*ageInt) + 5;
        }
        if (goalString.equalsIgnoreCase(weightString)){
            goalCal = BMS;
        }
        if (goalDouble > weightDouble){
            goalCal = BMS + 300;
        }
        if (goalDouble < weightDouble){
            goalCal = BMS - 50;
        }
        int intGoal  = (int)(Math.round(goalCal));
        String neededCal = Integer.toString(intGoal);
        cal_goal.setText(neededCal);
    }

    public void openEditProfile(){
        Intent intent = new Intent(this, ProfilePage.class);
        startActivity(intent);
    }

    public void readFile(){
        FileInputStream fis = null;
        File tempFile = new File("/data/data/com.example.nutritionlog/files/internal.txt");
       if (tempFile.exists()) {
           try {
               fis = openFileInput(FILE_NAME);
               InputStreamReader isr = new InputStreamReader(fis);
               BufferedReader br = new BufferedReader(isr);
               String text;

               int line;
               while ((text = br.readLine()) != null) {
                   sb.append(text).append("\n");
                   stringArray.add(text);
               }
           } catch (FileNotFoundException e) {
               e.printStackTrace();
           } catch (IOException e) {
               e.printStackTrace();
           } finally {
               try {
                   if (fis != null) {
                       fis.close();
                   }
                   fis.close();
               } catch (IOException e) {
                   e.printStackTrace();
               }
           }
           if (fis != null) {
               int i;
               for (i = 0; i <= stringArray.size(); ++i) {
                   name.setText(stringArray.get(0));
                   dob.setText(stringArray.get(1) + "years");
                   ageString = stringArray.get(1);
                   gender.setText(stringArray.get(2));
                   height.setText(stringArray.get(3) + "cm");
                   heightString = stringArray.get(3);
                   weight.setText(stringArray.get(4) + "kg");
                   weightString = stringArray.get(4);
                   goal.setText(stringArray.get(5));
               }
               displayGoalCalories();
           }
       }
    }
}