package databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.List;

import Model.Food;

public class Database extends SQLiteAssetHelper {
    private static final String DB_NAME = "DB_NutritionLog";
    private static int DB_VER = 1;

    public Database(Context context) {
        super(context, DB_NAME, null, DB_VER);
    }

    //create method to get all food with all attributes(columns)
    public List<Food> getFood() {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"_id", "name", "Food_Group", "Calories", "Fat__g_", "Protein__g_", "Carbohydrate__g_"};
        String tableName = "Food";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, null, null, null, null, null);
        List<Food> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Food food = new Food();
                food.setId(cursor.getInt(cursor.getColumnIndex("_id")));
                food.setName(cursor.getString(cursor.getColumnIndex("name")));
                food.setCategory(cursor.getString(cursor.getColumnIndex("Food_Group")));
                food.setCalories(cursor.getDouble(cursor.getColumnIndex("Calories")));
                food.setFat(cursor.getDouble(cursor.getColumnIndex("Fat__g_")));
                food.setProtein(cursor.getDouble(cursor.getColumnIndex("Protein__g_")));
                food.setCarbs(cursor.getDouble(cursor.getColumnIndex("Carbohydrate__g_")));
                result.add(food);
            } while (cursor.moveToNext());
        }
        return result;
    }


    //Get all names
    public List<String> getNames() {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"name"};
        String tableName = "Food";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, null, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("name")));
            } while (cursor.moveToNext());
        }
        return result;

    }

    //get Food by Name
    public List<Food> getFoodByName(String name){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"_id", "name", "Food_Group", "Calories", "Fat__g_", "Protein__g_", "Carbohydrate__g_"};
        String tableName = "Food";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "name LIKE ?",new String[]{"%"+name+"%"}, null, null, null, null);
        List<Food> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Food food = new Food();
                food.setId(cursor.getInt(cursor.getColumnIndex("_id")));
                food.setName(cursor.getString(cursor.getColumnIndex("name")));
                food.setCategory(cursor.getString(cursor.getColumnIndex("Food_Group")));
                food.setCalories(cursor.getDouble(cursor.getColumnIndex("Calories")));
                food.setFat(cursor.getDouble(cursor.getColumnIndex("Fat__g_")));
                food.setProtein(cursor.getDouble(cursor.getColumnIndex("Protein__g_")));
                food.setCarbs(cursor.getDouble(cursor.getColumnIndex("Carbohydrate__g_")));
                result.add(food);
            } while (cursor.moveToNext());
        }
        return result;
    }

    public void insertFoodItem (int id, String name, String category, double calories, double fat, double protein
            , double carbs){
        ContentValues contentValues = new ContentValues();
        contentValues.put("_id", id);
        contentValues.put("name", name);
        contentValues.put("Food_Group", category);
        contentValues.put("Calories", calories);
        contentValues.put("Fat__g_", fat);
        contentValues.put("Protein__g_", protein);
        contentValues.put("Carbohydrate__g_", carbs);
        this.getWritableDatabase().insertOrThrow("Food", "", contentValues);

    }



}