package databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Model.Food;
import Model.Meal;

public class DatabaseConsumedFood extends SQLiteOpenHelper {
    Context mContext;

    public DatabaseConsumedFood(@Nullable Context context, @Nullable String name,
                                @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "ConsumedFood.db", factory, version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE CONSUMED(ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "NAME TEXT, CATEGORY TEXT, CALORIES REAL, FAT REAL, PROTEIN REAL, CARBS REAL," +
                "MEAL_TYPE TEXT, DATE TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertMeal(String name, String category, double calories, double fat, double protein
            , double carbs, String mealType, String date){
        ContentValues contentValues = new ContentValues();
        //contentValues.put("ID", id);
        contentValues.put("NAME", name);
        contentValues.put("CATEGORY", category);
        contentValues.put("CALORIES", calories);
        contentValues.put("FAT", fat);
        contentValues.put("PROTEIN", protein);
        contentValues.put("CARBS", carbs);
        contentValues.put("MEAL_TYPE", mealType);
        contentValues.put("DATE", date);
        this.getWritableDatabase().insertOrThrow("CONSUMED", "", contentValues);

    }

    public List<Meal> getMeal() {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"ID", "NAME", "CATEGORY", "CALORIES", "FAT", "PROTEIN", "CARBS", "MEAL_TYPE", "DATE"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, null, null, null, null, null);
        List<Meal> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Meal meal = new Meal();
                meal.setId(cursor.getInt(cursor.getColumnIndex("ID")));
                meal.setName(cursor.getString(cursor.getColumnIndex("NAME")));
                meal.setCategory(cursor.getString(cursor.getColumnIndex("CATEGORY")));
                meal.setCalories(cursor.getDouble(cursor.getColumnIndex("CALORIES")));
                meal.setFat(cursor.getDouble(cursor.getColumnIndex("FAT")));
                meal.setProtein(cursor.getDouble(cursor.getColumnIndex("PROTEIN")));
                meal.setCarbs(cursor.getDouble(cursor.getColumnIndex("CARBS")));
                meal.setMealType(cursor.getString(cursor.getColumnIndex("MEAL_TYPE")));
                meal.setDate(cursor.getString(cursor.getColumnIndex("DATE")));
                result.add(meal);
            } while (cursor.moveToNext());
        }
        return result;
    }

    public List<Meal> getMealByDate(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"CALORIES", "FAT", "PROTEIN", "CARBS"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE LIKE ?",new String[]{"%"+date+"%"}, null, null, null, null);
        List<Meal> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Meal meal = new Meal();
                meal.setId(cursor.getInt(cursor.getColumnIndex("ID")));
                meal.setName(cursor.getString(cursor.getColumnIndex("NAME")));
                meal.setCategory(cursor.getString(cursor.getColumnIndex("CATEGORY")));
                meal.setCalories(cursor.getDouble(cursor.getColumnIndex("CALORIES")));
                meal.setFat(cursor.getDouble(cursor.getColumnIndex("FAT")));
                meal.setProtein(cursor.getDouble(cursor.getColumnIndex("PROTEIN")));
                meal.setCarbs(cursor.getDouble(cursor.getColumnIndex("CARBS")));
                meal.setMealType(cursor.getString(cursor.getColumnIndex("MEAL_TYPE")));
                meal.setDate(cursor.getString(cursor.getColumnIndex("DATE")));
                result.add(meal);
            } while (cursor.moveToNext());
        }
        return result;
    }

    public List<String> getCaloriesBydate(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"CALORIES"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE LIKE ?",new String[]{"%"+date+"%"}, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("CALORIES")));
            } while (cursor.moveToNext());
        }
        return result;
    }

    public List<String> getFatByDate(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"FAT"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE LIKE ?",new String[]{"%"+date+"%"}, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("FAT")));
            } while (cursor.moveToNext());
        }
        return result;
    }

    public List<String> getProteinByDate(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"PROTEIN"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE LIKE ?",new String[]{"%"+date+"%"}, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("PROTEIN")));
            } while (cursor.moveToNext());
        }
        return result;
    }

    public List<String> getCarbsByDate(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"CARBS"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE LIKE ?",new String[]{"%"+date+"%"}, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("CARBS")));
            } while (cursor.moveToNext());
        }
        return result;
    }

    public List<Meal> getBreakfastByDate(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"ID", "NAME", "CATEGORY", "CALORIES", "FAT", "PROTEIN", "CARBS", "MEAL_TYPE", "DATE"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE LIKE ? AND MEAL_TYPE LIKE ?",new String[]{"%"+date+"%", "Breakfast"}, null, null, null, null);
        /*Cursor cursor = qb.query(db, sqlSelect, SqLiteTableData.TableStructure.KEY_BOOKING_DATE+"= ? AND"SqLiteTableData.TableStructure.KEY_BOOKING_TIME+"= ?", new String[]{a,b},null, null);
        */
        List<Meal> result = new ArrayList<>();
        List<Meal> breakfastResult = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Meal meal = new Meal();
                meal.setId(cursor.getInt(cursor.getColumnIndex("ID")));
                meal.setName(cursor.getString(cursor.getColumnIndex("NAME")));
                meal.setCategory(cursor.getString(cursor.getColumnIndex("CATEGORY")));
                meal.setCalories(cursor.getDouble(cursor.getColumnIndex("CALORIES")));
                meal.setFat(cursor.getDouble(cursor.getColumnIndex("FAT")));
                meal.setProtein(cursor.getDouble(cursor.getColumnIndex("PROTEIN")));
                meal.setCarbs(cursor.getDouble(cursor.getColumnIndex("CARBS")));
                meal.setMealType(cursor.getString(cursor.getColumnIndex("MEAL_TYPE")));
                meal.setDate(cursor.getString(cursor.getColumnIndex("DATE")));
                result.add(meal);
            } while (cursor.moveToNext());
        }
        return result;
        }

    public List<Meal> getLunchByDate(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"ID", "NAME", "CATEGORY", "CALORIES", "FAT", "PROTEIN", "CARBS", "MEAL_TYPE", "DATE"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE LIKE ? AND MEAL_TYPE LIKE ?",new String[]{"%"+date+"%", "Lunch"}, null, null, null, null);
        /*Cursor cursor = qb.query(db, sqlSelect, SqLiteTableData.TableStructure.KEY_BOOKING_DATE+"= ? AND"SqLiteTableData.TableStructure.KEY_BOOKING_TIME+"= ?", new String[]{a,b},null, null);
         */
        List<Meal> result = new ArrayList<>();
        List<Meal> breakfastResult = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Meal meal = new Meal();
                meal.setId(cursor.getInt(cursor.getColumnIndex("ID")));
                meal.setName(cursor.getString(cursor.getColumnIndex("NAME")));
                meal.setCategory(cursor.getString(cursor.getColumnIndex("CATEGORY")));
                meal.setCalories(cursor.getDouble(cursor.getColumnIndex("CALORIES")));
                meal.setFat(cursor.getDouble(cursor.getColumnIndex("FAT")));
                meal.setProtein(cursor.getDouble(cursor.getColumnIndex("PROTEIN")));
                meal.setCarbs(cursor.getDouble(cursor.getColumnIndex("CARBS")));
                meal.setMealType(cursor.getString(cursor.getColumnIndex("MEAL_TYPE")));
                meal.setDate(cursor.getString(cursor.getColumnIndex("DATE")));
                result.add(meal);
            } while (cursor.moveToNext());
        }
        return result;
    }

    public List<Meal> getDinnerByDate(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"ID", "NAME", "CATEGORY", "CALORIES", "FAT", "PROTEIN", "CARBS", "MEAL_TYPE", "DATE"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE LIKE ? AND MEAL_TYPE LIKE ?",new String[]{"%"+date+"%", "Dinner"}, null, null, null, null);
        /*Cursor cursor = qb.query(db, sqlSelect, SqLiteTableData.TableStructure.KEY_BOOKING_DATE+"= ? AND"SqLiteTableData.TableStructure.KEY_BOOKING_TIME+"= ?", new String[]{a,b},null, null);
         */
        List<Meal> result = new ArrayList<>();
        List<Meal> breakfastResult = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Meal meal = new Meal();
                meal.setId(cursor.getInt(cursor.getColumnIndex("ID")));
                meal.setName(cursor.getString(cursor.getColumnIndex("NAME")));
                meal.setCategory(cursor.getString(cursor.getColumnIndex("CATEGORY")));
                meal.setCalories(cursor.getDouble(cursor.getColumnIndex("CALORIES")));
                meal.setFat(cursor.getDouble(cursor.getColumnIndex("FAT")));
                meal.setProtein(cursor.getDouble(cursor.getColumnIndex("PROTEIN")));
                meal.setCarbs(cursor.getDouble(cursor.getColumnIndex("CARBS")));
                meal.setMealType(cursor.getString(cursor.getColumnIndex("MEAL_TYPE")));
                meal.setDate(cursor.getString(cursor.getColumnIndex("DATE")));
                result.add(meal);
            } while (cursor.moveToNext());
        }
        return result;
    }
    public void deleteMeal(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("CONSUMED", "ID=?", new String[]{id});
    }

    //WEEKLY DATA
    public List<String> getCaloriesByTimeRange(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"CALORIES"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE >=?",new String[]{date}, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("CALORIES")));
            } while (cursor.moveToNext());
        }
        return result;
    }
    public List<String> getFatByTimeRange(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"FAT"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE >=?",new String[]{date}, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("FAT")));
            } while (cursor.moveToNext());
        }
        return result;
    }
    public List<String> getProteinByTimeRange(String date){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"PROTEIN"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "DATE >=?",new String[]{date}, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("PROTEIN")));
            } while (cursor.moveToNext());
        }
        return result;
    }

    public List<String> getCarbsByTimeRange(String date) throws IOException {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //get every column from the table
        String[] sqlSelect = {"CARBS"};
        String tableName = "CONSUMED";

        qb.setTables(tableName);
        //db.execSQL("SELECT CARBS FROM CONSUMED WHERE datetime(DATE) BETWEEN datetime(date) AND dateTime('15/10/2020')");
        Cursor cursor = qb.query(db, sqlSelect, "DATE >=?", new String[]{date}, null, null, null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("CARBS")));
            } while (cursor.moveToNext());
        }
        return result;
    }
/*

    public void changeTableDateFormat() throws IOException {
        SQLiteDatabase db = getReadableDatabase();
        db.execSQL("DROP TABLE newConsumed");
        db.execSQL("CREATE TABLE newConsumed(ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "NAME TEXT, CATEGORY TEXT, CALORIES REAL, FAT REAL, PROTEIN REAL, CARBS REAL," +
                "MEAL_TYPE TEXT, DATE TEXT)");
        db.execSQL("INSERT INTO newConsumed SELECT * FROM CONSUMED");
        String command = "UPDATE newConsumed SET DATE = substr(calendar_day, 7) || '-' || substr(calendar_day,4,2)  || "-" || substr(calendar_day, 1,2)";
        db.execSQL(command);
        }


*/



}
